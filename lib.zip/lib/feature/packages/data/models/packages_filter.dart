import 'dart:convert';

import 'package:app/core/shared/imports.dart';
import 'package:equatable/equatable.dart';

class PackagesFilterModel extends Equatable {
  final int setNumber;
  const PackagesFilterModel({
    required this.setNumber,
  });

  PackagesFilterModel copyWith({
    int? setNumber,
  }) {
    return PackagesFilterModel(
      setNumber: setNumber ?? this.setNumber,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'setNumber': setNumber,
    };
  }

  factory PackagesFilterModel.fromMap(Map<String, dynamic> map) {
    return PackagesFilterModel(
      setNumber: map['setNumber']?.toInt() ?? 0,
    );
  }

  String toJson() => json.encode(toMap());

  factory PackagesFilterModel.fromJson(String source) =>
      PackagesFilterModel.fromMap(json.decode(source));

  @override
  String toString() => 'PackagesFilterModel(setNumber: $setNumber)';

  @override
  List<Object> get props => [setNumber];
}
